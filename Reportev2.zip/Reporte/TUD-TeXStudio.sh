#!/bin/bash
export TEXINPUTS=.:/home/beren/Libraries/Latex/tudtemplates//:
texstudio *.tex
